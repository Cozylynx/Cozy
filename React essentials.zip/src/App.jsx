import Header from "./components/Header.jsx";
import { useState } from "react";
import componentsImg from "./assets/components.png";
import { CORE_CONCEPTS } from "./data.js";
import CoreConcept from "./components/CoreConcept.jsx";
import Tab_Button from "./components/Tab_button1.jsx";
import { EXAMPLES } from "./data.js";

function genRandomInt(max) {
  return Math.floor(Math.random() * (max + 1));
}

function App() {
  const [selectedTopic, setSelectedTopic] = useState();
  function handleSelect(selectedButton) {
    setSelectedTopic(selectedButton);
    console.log(tabContent);
  }
  let tabContent = <p> Please select a Topic.</p>;
  if (selectedTopic) {
    tabContent = (
      <div id="tab-content">
        <h3>{EXAMPLES[selectedTopic].title}</h3>
        <p>{EXAMPLES[selectedTopic].description}</p>
        <pre>
          <code>{EXAMPLES[selectedTopic].code}</code>
        </pre>
      </div>
    );
  }
  return (
    <div>
      <Header />
      <main>
        <section id="core-concepts">  
          <h2>Core Concepts</h2>
          <ul>
            {CORE_CONCEPTS.map((conceptItem)=>(<CoreConcept key ={conceptItem.title} {...conceptItem}/>
              ))}
           
          </ul>
        </section>
        <section id="examples">
          <h2>Examples </h2>
          <menu>
            <Tab_Button isSelected = {selectedTopic === 'components'}onSelect={() => handleSelect("components")}>
              Component
            </Tab_Button>
            <Tab_Button  isSelected = {selectedTopic === 'jsx'} onSelect={() => handleSelect("jsx")}>JSX</Tab_Button>
            <Tab_Button isSelected = {selectedTopic === 'props'} onSelect={() => handleSelect("props")}>
              Props
            </Tab_Button>
            <Tab_Button  isSelected = {selectedTopic === 'state'} onSelect={() => handleSelect("state")}>
              State
            </Tab_Button>
          </menu>
          {tabContent}
        </section>
      </main>
    </div>
  );
}

export default App;
